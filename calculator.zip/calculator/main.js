

function clearr() {
	document.getElementById('input').value='';
}


function num(number) {
	 document.getElementById('input').value+=number;
}

function operationn(op) {

document.getElementById('input').value+=op;

}

function equall() {


   document.getElementById('input').value=eval(document.getElementById('input').value);


}

